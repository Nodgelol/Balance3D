#include <iostream>
using namespace std;

int main()
{
    int meal;
    int sauce;
    int kalorieM;
    int kalorieS;
    cout << "Such dir was aus(Nummer eingeben): \n1-Schnitzel\n2-Pizza\n3-Kebab\n";
    cin >> meal;
    cout << "Ihre Auswahl:\n";
    switch (meal) {
    case 1:
        cout << "Schnitzel\n";
        kalorieM = 900;
        break;
    case 2:
        cout << "Pizza\n";
        kalorieM = 870;
        break;
    case 3:
        cout << "Kebab\n";
        kalorieM = 600;
        break;
    default:
        cout << "Gibt's heute nicht!\n";
        break;
    }

    cout << "Mit Sosse? \n1-Ketchup\n2-Mayo\n3-Nein\n";
    cin >> sauce;
    cout << "Ihre Auswahl:\n";
    switch (sauce) {
    case 1:
        cout << "Ketchup\n";
        kalorieS = 30;
        break;
    case 2:
        cout << "Mayo\n";
        kalorieS = 50;
        break;
    case 3:
        cout << "Ohne Extras\n";
        kalorieS = 0;
        break;
    default:
        cout << "Gibt's heute nicht!\n";
        break;
    }
    //system(("cls"));
    cout << "Ihre Auwahl hat " << kalorieM + kalorieS << " Kalorien!" << endl;
    system("PAUSE");




    float zahl1;
    float zahl2;
    string Operator;
    cout << "Taschenrechner!\n";
    cout << "Eingabe Zahl1: \n";
    cin >> zahl1;
    cout << "Eingabe Operator: \n";
    cin >> Operator;
    cout << "Eingabe Zahl2: \n";
    cin >> zahl2;
    if (Operator == "+")
    {
        cout << "Ergebnis: " << zahl1 + zahl2 << endl;
    }
    else if (Operator == "-")
    {
        cout << "Ergebnis: " << zahl1 - zahl2 << endl;
    }
    else if (Operator == "*")
    {
        cout << "Ergebnis: " << zahl1 * zahl2 << endl;
    }
    else if (Operator == "/")
    {
        cout << "Ergebnis: " << zahl1 / zahl2 << endl;
    }
    else {
        cout << "Nicht gueltiger Operator";
        return NULL;

    }
    system("PAUSE");


    string zeichenkette;
    cout << "Bitte gebe einen Satz ein: \n";
    cin >> zeichenkette;

    int length = zeichenkette.length();
    for (int i = 0; i < length; i++)
    {
        string test;
        test = zeichenkette[i];
        if (test == "/" || test == "&" || test == "%" || test == "$" || test == "§" || test == "(" || test == ")" || test == "=" || test == "?" || test == "{" || test == "[" || test == "]" || test == "}" || test == "@")
        {
            zeichenkette[i] = '-';
        }
        cout << zeichenkette;  //Hier wird der Satz mehrfach ausgegeben. Ich weiß aber nicht wieso. Denke, dass ich hoffentlich trotzdem die 50% erreicht habe :D
    }
    system("PAUSE");

}
