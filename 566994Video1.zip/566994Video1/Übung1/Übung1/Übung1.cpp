
#include <iostream>
#include <cstdlib>
using namespace std;
int main()
{
	/// <summary>
	/// Übung 1 Aufgabe 2
	/// </summary>
	/// <returns></returns>
	cout << "Hallo Welt\n\n!!!\n"  ;
	system("PAUSE");

	/// <summary>
	/// Übung 1 Aufgabe 3
	/// </summary>
	/// <returns></returns>
	double groesse;
	double gewicht;
	double bmi;

	cout << "Bitte gebe deine Koerpergroesse ein: \n";
	cin  >>  groesse;
	cout << "Bitte gebe dein Koerpergewicht ein: \n";
	cin  >> gewicht;
	bmi = gewicht / ((groesse * groesse)/10000);
	cout << "Dein BMI lautet: " << bmi << '\n';
	system("PAUSE");

	/// <summary>
	/// Übung 1 Aufgabe 4
	/// </summary>
	/// <returns></returns>
	cout << " min: " << numeric_limits<int>::min() << " max:  " << numeric_limits<int>::max() << " bits: " << numeric_limits<int>::digits << " is Signed: " << numeric_limits<int>::is_signed << '\n';
	cout << " min: " << numeric_limits<bool>::min() << " max:  " << numeric_limits<bool>::max() << " bits: " << numeric_limits<bool>::digits << " is Signed: " << numeric_limits<bool>::is_signed << '\n';
	cout << " min: " << numeric_limits<char>::min() << " max:  " << numeric_limits<char>::max() << " bits: " << numeric_limits<char>::digits << " is Signed: " << numeric_limits<char>::is_signed << '\n';
	cout << " min: " << numeric_limits<signed char>::min() << " max:  " << numeric_limits<signed char>::max() << " bits: " << numeric_limits<signed char>::digits << " is Signed: " << numeric_limits<signed char>::is_signed << '\n';
	cout << " min: " << numeric_limits<unsigned char>::min() << " max:  " << numeric_limits<unsigned char>::max() << " bits: " << numeric_limits<unsigned char>::digits << " is Signed: " << numeric_limits<unsigned char>::is_signed << '\n';
	cout << " min: " << numeric_limits<short>::min() << " max:  " << numeric_limits<short>::max() << " bits: " << numeric_limits<short>::digits << " is Signed: " << numeric_limits<short>::is_signed << '\n';
	cout << " min: " << numeric_limits<signed short>::min() << " max:  " << numeric_limits<signed short>::max() << " bits: " << numeric_limits<signed short>::digits << " is Signed: " << numeric_limits<signed short>::is_signed << '\n';
	cout << " min: " << numeric_limits<unsigned int>::min() << " max:  " << numeric_limits<unsigned int>::max() << " bits: " << numeric_limits<unsigned int>::digits << " is Signed: " << numeric_limits<int>::is_signed << '\n';
	cout << " min: " << numeric_limits<long>::min() << " max:  " << numeric_limits<long>::max() << " bits: " << numeric_limits<long>::digits << " is Signed: " << numeric_limits<int>::is_signed << '\n';
	cout << " min: " << numeric_limits<unsigned long>::min() << " max:  " << numeric_limits<unsigned long>::max() << " bits: " << numeric_limits<unsigned long>::digits << " is Signed: " << numeric_limits<int>::is_signed << '\n';
	system("PAUSE");

}
